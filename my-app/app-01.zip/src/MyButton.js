
function MyButton(){
    return (
    <h1>마이버튼
        <div>
            <button>OK</button>
        </div>
    </h1>
    )
}

export default MyButton