
function Gugudan3dan(){
    const dan = 3;
    return (
    <div>
        <h1>* {dan*10}단 *</h1>
        <ul>
            <li>3 * 1 = 3</li>
            <li>3 * 2 = 6</li>
            <li>3 * 3 = 9</li>
            <li>3 * 4 = 12</li>
        </ul>
    </div>
    )
}

export default Gugudan3dan