import React from 'react';

function GameHeader(props) {
    return (
        <div >
            <h1>숫자맞추기 게임 2</h1>
            <p>1 ~ 100 사이 숫자를 맞춰보세요</p>
        </div>
    );
}

export default GameHeader;