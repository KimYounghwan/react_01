import React from 'react';

function CssExam01(props) {
    return (
        <div className='App'>
            <h1 style={ {color:"red", border:"1px solid black"} }>인라인 Css</h1>
        </div>
    );
}

export default CssExam01;