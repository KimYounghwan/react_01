import React from 'react';

function GawibawiboHeader(props) {
    return (
        <div>
            <h1>가위바위보 게임</h1>
            <hr></hr>
            <h2>컴퓨터와 가위바위보를 해보세요</h2>
        </div>
    );
}

export default GawibawiboHeader;