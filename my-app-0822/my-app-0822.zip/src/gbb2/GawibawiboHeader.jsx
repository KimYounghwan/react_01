import React from 'react';

function GawibawiboHeader(props) {
    return (
        <div>
            <h1>가위바위보 게임</h1>
            <hr></hr>
        </div>
    );
}

export default GawibawiboHeader;