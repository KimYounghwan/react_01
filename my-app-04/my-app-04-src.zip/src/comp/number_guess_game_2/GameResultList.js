import React from 'react';

function GameResultList(props) {
    return (
        <div>
            <ul></ul>
        </div>
    );
}

export default GameResultList;