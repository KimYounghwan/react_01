import logo from './logo.svg';
import './App.css';
import app_css from "./App.css"

const styles = {
  border: '1px solid red',
  borderRadius: 16
}

function App() {
  return (
    <div className={app_css.App}>
      <h1>헬로 리액트</h1>
    </div>
  );
}

export default App;
